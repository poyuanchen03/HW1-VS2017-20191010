#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int money, t, y;
	float rate, totalmoney;

	rate = 10;

	printf("�п�J�����B(��):");
	scanf_s("%d", &money);

	for (t = 1; t <= 5; t++)
	{
		printf("�~�Q�v=%.2f\t", rate);

		totalmoney = money * (1 + (rate / 100));
		for (y = 1; y <= 14; y++)
		{
			totalmoney = totalmoney * (1 + (rate / 100));
		}
		printf("��Q�`���B=%.2f\n", totalmoney);
		rate = rate + 0.5;
	}
	system("pause");
	return 0;
}