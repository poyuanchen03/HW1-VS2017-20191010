#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int row, star, space;

	//Top 

	for (row = 1; row <= 9; row += 2)
	{
		for (space = (9 - row) / 2; space > 0; space--)
			printf(" ");

		for (star = 1; star <= row; star++)
			printf("*");

		printf("\n");
	}

	//Bot

	for (row = 7; row >= 0; row -= 2)
	{
		for (space = (9 - row) / 2; space > 0; space--)
			printf(" ");

		for (star = 1; star <= row; star++)
			printf("*");

		printf("\n");
	}

	system("pause");
	return 0;
}
