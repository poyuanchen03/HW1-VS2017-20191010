#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i, j;

	for (i = 1; i <= 10; i++)
	{
		for (j = 0; j < i; j++)
		{
			printf("%s", "*");
		}
		printf("\n");
	}
	printf("\n");
	for (i = 1; i <= 10; i++)
	{
		for (j = 11; j > i; j--)
		{
			printf("%s", "*");
		}
		printf("\n");
	}
	printf("\n");
	for (i = 1; i <= 10; i++)
	{
		for (j = 1; j < i; j++)
		{
			printf("%s", " ");
		}
		for (j = 11; j > i; j--)
		{
			printf("%s", "*");
		}
		printf("\n");
	}
	printf("\n");
	for (i = 1; i <= 10; i++)
	{
		for (j = 10; j > i; j--)
		{
			printf("%s", " ");
		}
		for (j = 0; j < i; j++)
		{
			printf("%s", "*");
		}
		printf("\n");
	}
	printf("\n");

	system("pause");
	return 0;
}