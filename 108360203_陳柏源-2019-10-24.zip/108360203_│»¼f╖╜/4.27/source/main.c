#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i, j, k;

	for (i = 1; i <= 500; i++)
	{
		for (j = 1; j <= 500; j++)
		{
			for (k = 1; k <= 500; k++)
			{
				if ((i * i) + (j * j) == k * k && k <= 500)
				{
					printf("i=%d\t j=%d\t k=%d\t\n", i, j, k);
				}
			}
		}
	}

	system("pause");
	return 0;
}
