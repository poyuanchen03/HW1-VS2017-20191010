#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i;
	for (i = 1;i <= 12;i++)
	{
		printf("%s", "*");
	}
	printf("\n");
	for (i = 1; i <= 12; i++)
	{
		if ((i == 1) || (i == 12))
		{
			printf("%s", "*");
		}
		else
		{ 
			printf("%s", " ");
		}
			

	}
	printf("\n");
	for (i = 1; i <= 12; i++)
	{
		printf("%s", "*");
	}
	printf("\n");
	system("pause");
	return 0;


}