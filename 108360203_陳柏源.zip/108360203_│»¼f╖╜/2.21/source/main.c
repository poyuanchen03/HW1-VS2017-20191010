#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"

int main(void)
{
	User_defined_print();
	printf("*********         ***           *          *\n");
	printf("*       *       *     *        ***        * *\n");
	printf("*       *      *       *      *****      *   *\n"); 
	printf("*       *      *       *        *       *     *\n");
	printf("*       *      *       *        *      *       *\n");
	printf("*       *      *       *        *       *     *\n");
	printf("*       *      *       *        *        *   *\n");
	printf("*       *       *     *         *         * *\n");
	printf("*********         ***           *          *\n");
	system("pause");
	return 0;
}