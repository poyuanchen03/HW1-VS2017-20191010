#include <stdio.h>
#include <stdlib.h>

int User_defined_print()
{
	printf("My C++ program.\n");
	return 0;
}