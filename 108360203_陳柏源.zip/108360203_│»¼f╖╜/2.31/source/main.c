#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"

int main(void)
{
	int n0 = 0;
	int n1 = 1;
	int n2 = 2;
	int n3 = 3;
	int n4 = 4;
	int n5 = 5;
	int n6 = 6;
	int n7 = 7;
	int n8 = 8;
	int n9 = 9;
	int n10 = 10;

	printf("number\t square\t cube\t\n");
	printf("%d\t %d\t %d\t\n", n0, n0 * n0, n0 * n0 * n0);
	printf("%d\t %d\t %d\t\n", n1, n1 * n1, n1 * n1 * n1);
	printf("%d\t %d\t %d\t\n", n2, n2 * n2, n2 * n2 * n2);
	printf("%d\t %d\t %d\t\n", n3, n3 * n3, n3 * n3 * n3);
	printf("%d\t %d\t %d\t\n", n4, n4 * n4, n4 * n4 * n4);
	printf("%d\t %d\t %d\t\n", n5, n5 * n5, n5 * n5 * n5);
	printf("%d\t %d\t %d\t\n", n6, n6 * n6, n6 * n6 * n6);
	printf("%d\t %d\t %d\t\n", n7, n7 * n7, n7 * n7 * n7);
	printf("%d\t %d\t %d\t\n", n8, n8 * n8, n8 * n8 * n8);
	printf("%d\t %d\t %d\t\n", n9, n9 * n9, n9 * n9 * n9);
	printf("%d\t %d\t %d\t\n", n10, n10 * n10, n10 * n10 * n10);
	system("pause");
	return 0;
	
}