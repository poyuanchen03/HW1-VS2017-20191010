#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"
int main(void)
{
	int n1, modcheck;
	User_defined_print();
	printf("�п�J�@�Ӽ�:");
	scanf_s("%d", &n1);
	modcheck = n1%2;

	if (modcheck == 0)
	{
		printf("%d������\n", n1);
	}
	if (modcheck != 0)
	{
		printf("%d���_��\n", n1);
	}
	system("pause");
	return 0;
}