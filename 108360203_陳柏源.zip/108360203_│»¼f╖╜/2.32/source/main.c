#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"

int main(void)
{
	int weight, height, BMI;
	printf("�н��J�魫(����)�P����(����)�A�������Ů�:");
	scanf_s("%d %d", &weight, &height);
	BMI = weight / (height * height);
	printf("BMI=%d\n", BMI);
	if (BMI < 18.5)
	{
		printf("Your BMI is underweight\n");
	}
	if ((BMI >= 18.5) && (BMI <= 24.9))
	{
		printf("Your BMI is normal\n");
	}
	if ((BMI >= 25) && (BMI <= 29.9))
	{
		printf("Your BMI is overweight\n");
	}
	if (BMI >= 30)
	{
		printf("Your BMI is obese\n");
	}
	system("pause");
	return 0;
}