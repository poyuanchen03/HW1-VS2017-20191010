#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"

int main(void)
{
	User_defined_print();
	printf("PPPPPPPPPPPP\n");
	printf("      P    P\n");
	printf("      P    P\n");
	printf("      P    P\n");
	printf("       PPPP\n\n");
	printf("           Y\n");
	printf("         Y\n");
	printf("YYYYYYYY\n");
	printf("         Y\n");
	printf("           Y\n\n");
	printf("    CCCC\n");
	printf("  C      C\n");
	printf("C          C\n");
	printf("C          C\n");
	printf(" C        C\n");
	system("pause");
	return 0;
}