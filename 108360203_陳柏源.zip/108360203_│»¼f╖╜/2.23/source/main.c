#include <stdio.h>
#include <stdlib.h>
#include "User_defined.h"

int main(void)
{
	User_defined_print();
	int n1,n2,n3,max,min;
	printf("�п�J�T�ӼơA�����ݪŮ�:");
	scanf_s("%d %d %d", &n1, &n2, &n3);

	if ((n1 > n2) && (n1 > n3))
	{
		printf("the max number is : %d\n", n1);
	}
	if ((n2 > n1) && (n2 > n3))
	{
		printf("the max number is : %d\n", n2);
	}
	if ((n3 > n1) && (n3 > n2))
	{
		printf("the max number is : %d\n", n3);
	}
	
	if ((n1 < n2) && (n1 < n3))
	{
		printf("the min number is : %d\n", n1);
	}
	if ((n2 < n1) && (n2 < n3))
	{
		printf("the min number is : %d\n", n2);
	}
	if ((n3 < n1) && (n3 < n2))
	{
		printf("the min number is : %d\n", n3);
	}

	
	system("pause");
	return 0;
}